import numpy as np
import pandas as pd

from sklearn.manifold import TSNE
import matplotlib.pyplot as plt

def visualize_augmented_tsne(original_data, new_samples_list, sample_size=2000):
    print("📊 正在执行增强样本 t-SNE 可视化...")

    if isinstance(original_data, pd.DataFrame):
        original_data = original_data.values

    all_new = np.vstack(new_samples_list)
    all_data = np.vstack((original_data, all_new))

    features = all_data[:, :-1]
    labels = all_data[:, -1].astype(int)

    if len(features) > sample_size:
        # 随机下采样显示
        indices = np.random.choice(len(features), size=sample_size, replace=False)
        features = features[indices]
        labels = labels[indices]
        is_aug = np.isin(indices, range(len(original_data)))
    else:
        is_aug = np.array([i >= len(original_data) for i in range(len(all_data))])

    tsne = TSNE(n_components=2, perplexity=30, random_state=42)
    embedding = tsne.fit_transform(features)

    plt.figure(figsize=(10, 8))
    scatter = plt.scatter(
        embedding[:, 0], embedding[:, 1],
        c=labels, cmap="tab10",
        marker='o', s=20, alpha=0.6,
        edgecolors='k'
    )

    # 用不同 marker 标出增强样本
    if np.any(~is_aug):
        plt.scatter(
            embedding[~is_aug, 0], embedding[~is_aug, 1],
            c=labels[~is_aug], cmap="tab10",
            marker='x', s=30, linewidths=1.5, alpha=0.7, label="Original"
        )

    plt.title("t-SNE visualization of original vs augmented samples")
    plt.legend(*scatter.legend_elements(), title="Class")
    plt.grid(True)
    plt.tight_layout()
    plt.show()



def visualize_embedding_comparison(original_X, mapped_X, labels, title):
    from sklearn.manifold import TSNE
    import matplotlib.pyplot as plt

    n = min(1000, len(original_X))  # 降采样
    idx = np.random.choice(len(original_X), size=n, replace=False)

    X_ori = original_X[idx]
    X_map = mapped_X[idx]
    y = labels[idx]

    tsne_ori = TSNE(n_components=2, random_state=42).fit_transform(X_ori)
    tsne_map = TSNE(n_components=2, random_state=42).fit_transform(X_map)

    fig, axes = plt.subplots(1, 2, figsize=(12, 5))
    for ax, emb, title_part in zip(axes, [tsne_ori, tsne_map], ["原空间", "嵌入空间"]):
        scatter = ax.scatter(emb[:, 0], emb[:, 1], c=y, cmap="tab10", s=20, alpha=0.6)
        ax.set_title(f"{title} - {title_part}")
        ax.grid(True)
    plt.legend(*scatter.legend_elements(), title="Class", loc='best')
    plt.tight_layout()
    plt.show()
