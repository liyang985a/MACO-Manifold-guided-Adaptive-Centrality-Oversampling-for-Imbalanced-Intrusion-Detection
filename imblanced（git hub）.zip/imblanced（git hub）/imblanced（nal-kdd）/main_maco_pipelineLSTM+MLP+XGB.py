# ========== Standard Library ==========
import warnings
from collections import Counter
from statistics import mean, stdev

# ========== Third-Party Libraries ==========
import numpy as np
import pandas as pd
from imblearn.over_sampling import ADASYN

from sklearn.decomposition import PCA
from sklearn.manifold import LocallyLinearEmbedding, Isomap
from sklearn.metrics import (
    precision_score, recall_score, f1_score, accuracy_score,
    classification_report, confusion_matrix
)
from sklearn.model_selection import StratifiedKFold
from sklearn.neighbors import KDTree, NearestNeighbors
from scipy.spatial import KDTree as SciPyKDTree
from scipy.spatial.distance import pdist
from scipy.sparse import SparseEfficiencyWarning
from sklearn.kernel_approximation import Nystroem

# ========== PyTorch ==========
import torch.nn as nn
from sklearn.svm import SVC
from torch.cuda import is_available

# ========== Custom Modules ==========
from fig import visualize_embedding_comparison, visualize_augmented_tsne
from model2 import train_mlp_once, measures_of_classify
from manifold_mapperLSTMMLPXGB import neighborhood_Measure_mm

# ========== Warnings ==========
warnings.simplefilter("ignore", SparseEfficiencyWarning)

###4.4，4.5

from sklearn.neighbors import KDTree
import numpy as np
# ========== 新增依赖 ==========
import os
import matplotlib.pyplot as plt  # ✅ 修复了致命的导入语法错误
import seaborn as sns
from scipy.stats import ttest_rel
from xgboost import XGBClassifier
from lightgbm import LGBMClassifier
import torch
import torch.nn as nn
from torch.utils.data import DataLoader, TensorDataset
import torch.optim as optim


# ==========================================
# 1. 新增分类器 Wrappers (XGBoost, LightGBM)
# ==========================================
def train_xgb_once(X_train, y_train, X_test, y_test, num_classes, device_id=None):
    """XGBoost 分类器 Wrapper"""
    # ✅ 转换为纯 numpy 数组，彻底消除 Feature names 警告
    X_tr_clean = np.asarray(X_train)
    X_te_clean = np.asarray(X_test)

    # 随机种子交由全局 numpy 种子控制，确保多次运行有微小方差
    seed = np.random.randint(0, 10000)

    model = XGBClassifier(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        objective='multi:softmax',
        num_class=num_classes,
        eval_metric='mlogloss',
        random_state=seed,
        n_jobs=-1
    )
    model.fit(X_tr_clean, y_train)
    y_pred = model.predict(X_te_clean)
    return y_test, y_pred


def train_lgbm_once(X_train, y_train, X_test, y_test, num_classes, device_id=None):
    """LightGBM 分类器 Wrapper"""
    # ✅ 转换为纯 numpy 数组，彻底消除 Feature names 警告
    X_tr_clean = np.asarray(X_train)
    X_te_clean = np.asarray(X_test)

    seed = np.random.randint(0, 10000)

    model = LGBMClassifier(
        n_estimators=100,
        max_depth=6,
        learning_rate=0.1,
        objective='multiclass',
        num_class=num_classes,
        random_state=seed,
        n_jobs=-1,
        verbose=-1
    )
    model.fit(X_tr_clean, y_train)
    y_pred = model.predict(X_te_clean)
    return y_test, y_pred


# ==========================================
# 2. 深度学习序列模型 (LSTM) Wrapper
# ==========================================
class SimpleLSTM(nn.Module):
    def __init__(self, input_dim, hidden_dim, num_classes):
        super(SimpleLSTM, self).__init__()
        self.lstm = nn.LSTM(input_dim, hidden_dim, batch_first=True)
        self.fc = nn.Linear(hidden_dim, num_classes)

    def forward(self, x):
        out, _ = self.lstm(x)
        out = self.fc(out[:, -1, :])
        return out


def train_lstm_once(X_train, y_train, X_test, y_test, num_classes, device_id=None, epochs=20, batch_size=256):
    """LSTM 分类器 Wrapper (仅用于下游验证)"""
    device = torch.device(f"cuda:{device_id}" if torch.cuda.is_available() and device_id is not None else "cpu")

    X_tr_clean = np.asarray(X_train)
    X_te_clean = np.asarray(X_test)

    X_tr_tensor = torch.tensor(X_tr_clean, dtype=torch.float32).unsqueeze(1).to(device)
    y_tr_tensor = torch.tensor(y_train, dtype=torch.long).to(device)
    X_te_tensor = torch.tensor(X_te_clean, dtype=torch.float32).unsqueeze(1).to(device)

    dataset = TensorDataset(X_tr_tensor, y_tr_tensor)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    model = SimpleLSTM(input_dim=X_train.shape[1], hidden_dim=64, num_classes=num_classes).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=0.001)

    model.train()
    for epoch in range(epochs):
        for batch_X, batch_y in loader:
            optimizer.zero_grad()
            outputs = model(batch_X)
            loss = criterion(outputs, batch_y)
            loss.backward()
            optimizer.step()

    model.eval()
    with torch.no_grad():
        test_outputs = model(X_te_tensor)
        _, y_pred = torch.max(test_outputs.data, 1)

    return y_test, y_pred.cpu().numpy()


# ==========================================
# 3. 统计检验与自动化绘图函数
# ==========================================
def perform_stat_test_and_plot(results_dict, metric_name="Macro F1"):
    plot_data = []
    summary_data = []  # 用于导出 CSV 表格

    print(f"\n📈 ===== {metric_name} 统计显著性检验 (Paired T-test) =====")
    for model_name, (base_list, aug_list) in results_dict.items():
        # 配对 T 检验
        t_stat, p_val = ttest_rel(base_list, aug_list)
        significance = "***" if p_val < 0.001 else "**" if p_val < 0.01 else "*" if p_val < 0.05 else "ns"

        print(f"[{model_name}] Baseline vs MACO -> p-value: {p_val:.4e} ({significance})")

        # 整理用于画图的数据
        for val in base_list:
            plot_data.append({"Model": model_name, "Method": "Baseline", metric_name: val})
        for val in aug_list:
            plot_data.append({"Model": model_name, "Method": "MACO Augmented", metric_name: val})

        # 整理用于制表的数据
        base_mean, base_std = mean(base_list), stdev(base_list)
        aug_mean, aug_std = mean(aug_list), stdev(aug_list)
        improvement = (aug_mean - base_mean) / base_mean * 100

        summary_data.append({
            "Classifier": model_name,
            "Baseline (Mean ± Std)": f"{base_mean:.4f} ± {base_std:.4f}",
            "MACO (Mean ± Std)": f"{aug_mean:.4f} ± {aug_std:.4f}",
            "Improvement (%)": f"+{improvement:.2f}%",
            "p-value": f"{p_val:.4e}",
            "Significance": significance
        })

    import pandas as pd
    df_plot = pd.DataFrame(plot_data)
    df_summary = pd.DataFrame(summary_data)

    # 💾 导出 1：统计学表格 (CSV)
    table_filename = "Statistical_Significance_Report.csv"
    df_summary.to_csv(table_filename, index=False)
    print(f"✅ 统计表格已保存至: {os.path.abspath(table_filename)}")

    # 🎨 导出 2：带误差棒的柱状图 (Bar Plot)
    plt.figure(figsize=(10, 6))
    sns.set_theme(style="whitegrid")
    ax1 = sns.barplot(x="Model", y=metric_name, hue="Method", data=df_plot, capsize=.1, palette="Set2")
    plt.title(f"Generalization Across Classifiers: {metric_name}", fontsize=14, fontweight='bold')
    plt.ylabel(metric_name, fontsize=12)
    plt.xlabel("Classifier Architecture", fontsize=12)
    plt.legend(title="Data Setup", loc='lower right')
    bar_filename = f"Generalization_BarPlot_{metric_name.replace(' ', '_')}.png"
    plt.savefig(bar_filename, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"✅ 柱状图已保存至: {os.path.abspath(bar_filename)}")

    # 🎨 导出 3：箱线图 + 散点图 (Box Plot) - 专门用于回应随机性和方差
    plt.figure(figsize=(10, 6))
    sns.set_theme(style="ticks")
    ax2 = sns.boxplot(x="Model", y=metric_name, hue="Method", data=df_plot, palette="pastel", width=0.6, fliersize=0)
    # 添加散点展示具体的 5 次运行分布
    sns.stripplot(x="Model", y=metric_name, hue="Method", data=df_plot, dodge=True, color='black', alpha=0.6, ax=ax2)

    # 移除重复的图例
    handles, labels = ax2.get_legend_handles_labels()
    plt.legend(handles[0:2], labels[0:2], title="Data Setup", loc='lower right')

    plt.title(f"Robustness Across Random Seeds (5 Runs): {metric_name}", fontsize=14, fontweight='bold')
    plt.ylabel(metric_name, fontsize=12)
    plt.xlabel("Classifier Architecture", fontsize=12)
    box_filename = f"Robustness_BoxPlot_{metric_name.replace(' ', '_')}.png"
    plt.savefig(box_filename, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"✅ 箱线图已保存至: {os.path.abspath(box_filename)}")

def estimate_local_sigma(x, global_features, global_labels, y, k=5):
    indices = np.where(global_labels == y)[0]
    if len(indices) < 2:
        return 1.0
    tree = KDTree(global_features[indices])
    dists, _ = tree.query(x.reshape(1, -1), k=min(k + 1, len(indices)))
    avg_dist = np.mean(dists[0][1:])  # 排除自己
    return max(avg_dist, 1e-6)


def get_top_opp_classes(global_features, global_labels, target_class, top_n=2):
    cls_centers = {}
    target_mask = (global_labels == target_class)
    if np.sum(target_mask) == 0:
        return []

    target_center = np.mean(global_features[target_mask], axis=0)

    for cls in np.unique(global_labels):
        if cls == target_class:
            continue
        cls_mask = (global_labels == cls)
        if np.sum(cls_mask) == 0:
            continue
        center = np.mean(global_features[cls_mask], axis=0)
        cls_centers[cls] = np.linalg.norm(center - target_center)

    sorted_cls = sorted(cls_centers.items(), key=lambda x: x[1])
    return [cls for cls, _ in sorted_cls[:top_n]]


def cen_mar_func_top_opp(data, global_features, global_labels,
                         k_sim=3, k_opp=3, top_n_opp_classes=2, verbose=True):
    def stable_gaussian_weight(dist, sigma):
        sigma = max(sigma, 1e-2)
        weight = np.exp(-dist ** 2 / (2 * sigma ** 2))
        weight[weight < 1e-4] = 0
        return weight

    features = data[:, :-1]
    labels = data[:, -1]
    r = features.shape[0]
    Degree = np.zeros((r, 2))  # 中心性, 边缘性

    for i in range(r):
        x = features[i]
        y = labels[i]

        sigma = estimate_local_sigma(x, global_features, global_labels, y)

        # 同类邻居
        sim_indices_all = np.where(global_labels == y)[0]
        if len(sim_indices_all) >= 1:
            sim_tree = KDTree(global_features[sim_indices_all])
            _, sim_idx_local = sim_tree.query(x.reshape(1, -1), k=min(k_sim, len(sim_indices_all)))
            sim_indices = sim_indices_all[sim_idx_local[0]]
        else:
            sim_indices = []

        # 异类邻居
        top_opp_classes = get_top_opp_classes(global_features, global_labels, y, top_n=top_n_opp_classes)
        opp_indices_all = np.concatenate(
            [np.where(global_labels == c)[0] for c in top_opp_classes if np.sum(global_labels == c) > 0])
        if len(opp_indices_all) >= 1:
            opp_tree = KDTree(global_features[opp_indices_all])
            _, opp_idx_local = opp_tree.query(x.reshape(1, -1), k=min(k_opp, len(opp_indices_all)))
            opp_indices = opp_indices_all[opp_idx_local[0]]
        else:
            opp_indices = []

        if verbose:
            print(f"🔍 样本 {i} 类别 {y}：同类邻居数={len(sim_indices)}, 异类邻居数={len(opp_indices)}")

        if len(sim_indices) == 0 and len(opp_indices) == 0:
            if verbose:
                print(f"⚠️ 样本 {i} 无有效邻居，Degree 默认设为0")
            continue

        all_indices = np.concatenate([sim_indices, opp_indices])
        all_labels = global_labels[all_indices]
        all_features = global_features[all_indices]
        all_distances = np.linalg.norm(all_features - x, axis=1)
        weights = stable_gaussian_weight(all_distances, sigma)

        sim_mask = (all_labels == y)
        opp_mask = (all_labels != y)

        Degree[i, 0] = np.sum(weights[sim_mask]) if np.any(sim_mask) else 0.0
        Degree[i, 1] = np.sum(weights[opp_mask]) if np.any(opp_mask) else 0.0

        if verbose and i < 1:
            print(f"🎯 σ={sigma:.4f}, 距离={np.round(all_distances, 2)}")
            print(f"🎯 权重: {np.round(weights, 4)}")
            print(f"🎯 center sum: {Degree[i, 0]:.4f}, margin sum: {Degree[i, 1]:.4f}")

        if verbose and i < 1:
            print(f"🔍 样本 {i} 类别 {y}：")
            print(f"    同类候选样本数: {len(sim_indices_all)}，选中: {len(sim_indices)}")
            print(
                f"    异类候选类别: {top_opp_classes}，样本数: {len(opp_indices_all) if 'opp_indices_all' in locals() else 0}，选中: {len(opp_indices)}")

        if np.all(weights == 0):
            print(f"⚠️ 样本 {i} 所有邻居权重为 0，可能是 σ={sigma:.4f} 太小或邻居太远")

    return Degree


from sklearn.cluster import KMeans


def select_diverse_samples(features, labels, weights, filter_ratio=0.8, n_clusters=3, min_samples_no_cluster=50):
    selected_indices = []
    classes = np.unique(labels)

    for cls in classes:
        cls_mask = (labels == cls)
        cls_features = features[cls_mask]
        cls_weights = weights[cls_mask]
        cls_indices = np.where(cls_mask)[0]
        cls_size = len(cls_features)

        # ✅ 少数类，直接保留全部样本
        if cls_size < min_samples_no_cluster:
            print(f"📌 类别 {cls} 样本较少（{cls_size}），跳过聚类与筛选，保留全部")
            selected_indices.extend(cls_indices)
            continue

        # ✅ 正常类走筛选和聚类流程
        if cls_size < n_clusters:
            top_n = max(1, int(cls_size * filter_ratio))
            top_idx = np.argsort(-cls_weights)[:top_n]
            selected_indices.extend(cls_indices[top_idx])
            continue

        # 聚类+每簇筛选
        #kmeans = KMeans(n_clusters=n_clusters, random_state=42, n_init=10)
        kmeans = KMeans(n_clusters=n_clusters, n_init=10)

        cluster_labels = kmeans.fit_predict(cls_features)

        for cl in range(n_clusters):
            cluster_mask = (cluster_labels == cl)
            if not np.any(cluster_mask):
                continue
            cluster_weights = cls_weights[cluster_mask]
            cluster_idx_in_cls = np.where(cluster_mask)[0]
            top_n = max(1, int(len(cluster_weights) * filter_ratio))
            top_cluster_idx = np.argsort(-cluster_weights)[:top_n]
            selected_indices.extend(cls_indices[cluster_idx_in_cls[top_cluster_idx]])

    return np.array(selected_indices)


def over_multi_manifold(data, global_data, mapper=None, min_class_size=5,
                        use_score_filter=True, filter_ratio=0.8):  # ✅ 添加参数

    labels = data[:, -1]
    classes = np.unique(labels)

    class_counts = {cls: np.sum(labels == cls) for cls in classes}
    if any(v < min_class_size for v in class_counts.values()):
        for cls, cnt in class_counts.items():
            if cnt < min_class_size:
                print(f"⚠️ 类别 {cls} 样本数仅 {cnt}，跳过该类的多流形建模。")
        return np.array([]), np.array([]), np.array([])

    manifold, all_data_map, mapper = neighborhood_Measure_mm(data, mapper=mapper)
    num_mappings = len(all_data_map)
    r = data.shape[0]

    global_mapped_all = mapper.transform(global_data[:, :-1])
    Degree = np.zeros((r, 2, num_mappings))

    for j in range(num_mappings):
        mapping_type = manifold[0]['type'][j]
        mappedX = all_data_map[j]['all_x']

        map_data = np.hstack((mappedX, data[:, -1].reshape(-1, 1)))
        global_features_mapped = global_mapped_all[mapping_type]

        degree_result = cen_mar_func_top_opp(
            map_data,
            global_features_mapped,
            global_data[:, -1],
            k_sim=3,  # 基准3
            k_opp=3,  # 基准3
            top_n_opp_classes=3,  # 基准3
            verbose=False
        )

        if np.all(degree_result[:, 0] == 0) and np.all(degree_result[:, 1] == 0):
            print(f"⚠️ Degree 全为 0 - 映射方法 {mapping_type} 对所有样本无效，或邻居结构异常")

        Degree[:, 0, j] = degree_result[:, 0]
        Degree[:, 1, j] = degree_result[:, 1]

    weighted_cen = np.zeros((r, 1))
    weighted_mar = np.zeros((r, 1))

    # 确保类别与 manifold 顺序一致
    label_to_manifold_index = {cls: idx for idx, cls in enumerate(classes)}
    for i in range(r):
        cls_label = data[i, -1]
        if cls_label not in label_to_manifold_index:
            continue
        cls_index = label_to_manifold_index[cls_label]  # 正确的 manifold 对应下标

        alpha = manifold[cls_index]['alpha']
        if len(alpha) != num_mappings:
            print(f"⚠️ α 长度与 Degree 映射数不符，跳过样本 {i}")
            continue

        weighted_cen[i, 0] = np.dot(alpha, Degree[i, 0, :])
        weighted_mar[i, 0] = np.dot(alpha, Degree[i, 1, :])

    #weight = weighted_mar - weighted_cen
    weight = Degree[:, 1] / (Degree[:, 0] + 1e-6)  # W = mar / (cen + ε)

    if use_score_filter:
        # mask_marginal = weight[:, 0] > 0
        # weight_marginal = weight[mask_marginal]
        # data_marginal = data[mask_marginal]
        # label_marginal = data_marginal[:, -1]

        # 使用所有数据而不是仅weight>0的子集
        weight_marginal = weight
        data_marginal = data
        label_marginal = data[:, -1]

        if len(weight_marginal) == 0:
            print("⚠️ 无边缘样本可供筛选，返回空")
            return np.array([]), np.array([]), np.array([])

        selected_indices = select_diverse_samples(
            data_marginal[:, :-1],
            label_marginal,
            weight_marginal[:, 0],
            filter_ratio=filter_ratio,
            n_clusters=3,
            min_samples_no_cluster=100  # ✅ 加上这个参数
        )

        sorted_data = data_marginal[selected_indices]
        sorted_weight = weight_marginal[selected_indices]
        sort_label = label_marginal[selected_indices]
        # sorted_indices = np.argsort(-sorted_weight[:, 0])
        print(f"🎯 使用 score filter: weight>0 且 top {filter_ratio * 100:.0f}% ，保留 {len(sorted_weight)} 个样本")


    else:
        # ✅ 默认逻辑：使用所有样本（不筛选）
        sorted_indices = np.argsort(-weight[:, 0])
        sorted_weight = weight[sorted_indices]
        sorted_data = data[sorted_indices, :]
        sort_label = data[sorted_indices, -1]

    # print(f"✅ Degree 合成后（mar - cen）值范围: {weight.min():.4f} ~ {weight.max():.4f}")
    # print(f"📊 Top 10 样本 raw weight: {sorted_weight[:10].flatten()}")
    # print(f"📌 Top 10 样本标签: {sort_label[:10]}")
    # print(f"🎯 Top 10 样本中心性: {weighted_cen[sorted_indices[:10]].flatten()}")
    # print(f"🔍 Top 10 样本边缘性: {weighted_mar[sorted_indices[:10]].flatten()}")

    return sorted_weight, sorted_data, sort_label


###4.6

import numpy as np
from sklearn.neighbors import NearestNeighbors
from scipy.spatial.distance import pdist


def average_distance(minority_data):
    if minority_data.shape[0] < 2:
        return 0.0
    distances = pdist(minority_data, metric='euclidean')
    return np.mean(distances)


def gradual_overSampling_func_multi_plus(
        sorted_weight,
        sorted_data,
        sort_label,
        target_class,
        alpha=1.0,
        beta=0.1,
        k=5,
        max_iter=20,
        eps=0.005,
        n_generate_per_sample=1,
        smote_ratio=0.5,
        enable_smote=False
):
    r, c = sorted_data.shape
    class_data = sorted_data[sorted_data[:, c - 1] == target_class, :]
    if class_data.shape[0] == 0:
        print(f"⚠️ 类别 {target_class} 无边缘样本，跳过增强。")
        return np.array([]), 1.0  # fallback_ratio=1 表示失败

    print(f"\n✅ [类 {target_class}] 用于过采样的边缘样本数: {class_data.shape[0]}")

    features = np.array(class_data[:, :-1], dtype=np.float64)
    if features.ndim != 2 or features.shape[1] == 0:
        print(f"❌ 特征提取失败: 非法维度 {features.shape}")
        return np.array([]), 1.0

    nc, feature_dim = features.shape
    if nc <= 1:
        print(f"⚠️ 类别 {target_class} 样本过少，无法建立邻居结构。")
        return np.array([]), 1.0

    k_eff = min(k, nc - 1)
    if k_eff < 1:
        print(f"⚠️ 类别 {target_class} 可用样本不足，无法建立邻居结构。")
        return np.array([]), 1.0

    nbrs = NearestNeighbors(n_neighbors=k_eff + 1).fit(features)
    _, indices = nbrs.kneighbors(features)
    Idx = indices[:, 1:]

    ave_dist = average_distance(features)
    w = max(ave_dist * 0.05, 1e-3)

    generated_samples = []
    converge_iters = []
    fallback_count = 0
    smote_count = 0
    dict_success_count = 0
    dict_fallback_count = 0

    for i in range(nc):
        U = features[Idx[i, :], :].T
        center = features[i, :]

        for _ in range(n_generate_per_sample):
            if enable_smote and (np.random.rand() < smote_ratio):
                neighbor_idx = np.random.choice(Idx[i])
                neighbor_vec = features[neighbor_idx]
                lam = np.random.rand()
                x_i = lam * center + (1 - lam) * neighbor_vec
                generated_samples.append(x_i)
                converge_iters.append(0)
                smote_count += 1
                continue

            v_i = np.random.dirichlet(np.ones(k_eff) * 0.5)

            retry_count = 0
            max_retry = 5
            success = False

            for iter_id in range(max_iter):
                x_i = np.dot(U, v_i)

                if any(np.linalg.norm(x_i - features[Idx[i, j], :]) < w for j in range(k_eff)):
                    retry_count += 1
                    if retry_count >= max_retry:
                        generated_samples.append(x_i)
                        converge_iters.append(iter_id)
                        dict_success_count += 1
                        success = True
                        break
                    continue

                try:
                    v_candidate, *_ = np.linalg.lstsq(U, x_i, rcond=None)
                    v_candidate = np.maximum(v_candidate, 0)
                    if np.sum(v_candidate) == 0:
                        v_i = np.random.dirichlet(np.ones(k_eff) * 0.5)
                        continue
                    new_v_i = v_candidate / np.sum(v_candidate)
                except np.linalg.LinAlgError:
                    break

                if iter_id > 4 and np.linalg.norm(new_v_i - v_i) <= eps:
                    generated_samples.append(x_i)
                    converge_iters.append(iter_id)
                    dict_success_count += 1
                    success = True
                    break

                if iter_id == max_iter - 1:
                    generated_samples.append(x_i)
                    converge_iters.append(iter_id)
                    dict_success_count += 1
                    success = True
                    break

                v_i = new_v_i

            if not success:
                generated_samples.append(np.dot(U, v_i))
                converge_iters.append(max_iter)
                fallback_count += 1
                dict_fallback_count += 1

    if len(generated_samples) == 0:
        print(f"⚠️ 类别 {target_class} 无增强样本生成。")
        return np.array([]), 1.0

    Over = np.array(generated_samples)
    label_newdata = np.full((Over.shape[0], 1), target_class, dtype=sorted_data.dtype)
    Over_Sampling_Data = np.hstack((Over, label_newdata))
    Over_Sampling_Data = np.unique(Over_Sampling_Data, axis=0)

    if converge_iters:
        converge_iters = np.array(converge_iters)
        print(f"📊 插值总数: {len(converge_iters)}")
        print(f"📊 平均插值迭代轮数: {np.mean(converge_iters):.2f}，最大迭代数: {np.max(converge_iters)}")
        print(f"📌 Fallback（未收敛）插值样本数: {fallback_count}")
        print(f"📊 插值方式统计：")
        print(f"   ├─ SMOTE 插值数        : {smote_count}")
        print(f"   ├─ 字典插值成功数      : {dict_success_count}")
        print(f"   └─ 字典插值 Fallback数 : {dict_fallback_count}")

    return Over_Sampling_Data



##4.7


def over_classify_mlp(data, train_mlp_once_func,
                      min_class_size=5, max_rounds=3, kf=2, iter_num=2,
                      save_filename="augmented_data.csv"):
    if isinstance(data, pd.DataFrame):
        data = data.values

    labels = data[:, -1].astype(int)
    all_precision, all_recall, all_f1, all_acc = [], [], [], []
    final_new_samples = []

    # 🌟 终极修复：使用基于全局种子的随机数，确保5轮实验的交叉验证切分是真正独立的
    skf = StratifiedKFold(n_splits=kf, shuffle=True, random_state=np.random.randint(0, 10000))
    split_indices = list(skf.split(data[:, :-1], labels))

    for j in range(iter_num):
        print(f"\n🔁 第 {j + 1}/{iter_num} 次迭代中...")
        for i, (train_idx, test_idx) in enumerate(split_indices):
            print(f"   ▶️ 第 {i + 1}/{kf} 折交叉验证中...")
            d, t = data[train_idx], data[test_idx]

            label_counts = Counter(d[:, -1])
            counts = np.array(list(label_counts.values()))
            mean_count = np.mean(counts)
            threshold = 0.6 * mean_count
            valid_classes = [cls for cls, count in label_counts.items() if count < threshold]

            print(f"      - 当前类别样本数: {dict(label_counts)}")
            print(f"      - 平均样本数: {mean_count:.0f}，少数类阈值: {threshold:.0f}")
            print(f"      - 动态选出的可增强类别: {valid_classes}")

            if not valid_classes:
                print("⚠️ 当前无有效少数类，跳过增强")
                continue

            X_d, y_d = d[:, :-1], d[:, -1].astype(int)
            X_t, y_t = t[:, :-1], t[:, -1].astype(int)
            num_classes = len(np.unique(np.concatenate((y_d, y_t))))
            y_true, y_pred = train_mlp_once_func(X_d, y_d, X_t, y_t, num_classes, device_id=0)

            cm_before = confusion_matrix(y_true, y_pred, labels=range(num_classes))
            r0, p0, f0, _, acc0 = measures_of_classify(cm_before)
            best_f1, best_acc = f0, acc0
            over_data = d.copy()

            cumulative_new_samples = []  # ✅ 新增：记录所有增强轮次的样本

            print(f"      📊 原始 F1: {f0:.4f} | 准确率: {acc0:.4f}")

            for round_num in range(1, max_rounds + 1):
                print(f"      🔁 第 {round_num} 轮增强中...")
                new_data_all_classes = []

                for cls in valid_classes:
                    cls_data = over_data[over_data[:, -1] == cls]
                    if cls_data.shape[0] < min_class_size:
                        print(f"        ⚠️ 类别 {cls} 样本数太少，跳过增强")
                        continue

                    sorted_weight, sorted_data, sort_label = over_multi_manifold(
                        cls_data, d
                    )

                    if sorted_data.ndim != 2 or sorted_data.shape[0] == 0:
                        print(f"        ⚠️ 类别 {cls} 无法执行 over_multi_manifold，跳过增强")
                        continue

                    new_cls_data = gradual_overSampling_func_multi_plus(
                        sorted_weight, sorted_data, sort_label,
                        target_class=cls,
                        n_generate_per_sample=2,
                        enable_smote=True,
                        smote_ratio=0.8
                    )

                    if new_cls_data.size > 0:
                        target_count = int(np.mean(list(label_counts.values())))
                        current_count = label_counts[cls]
                        needed = target_count - current_count
                        if needed <= 0:
                            continue
                        max_add = min(needed, new_cls_data.shape[0])
                        new_cls_data = new_cls_data[:max_add]

                        print(f"        ✅ 类别 {cls} 增强样本: {new_cls_data.shape[0]}（原始: {label_counts[cls]}）")
                        new_data_all_classes.append(new_cls_data)
                    else:
                        print(f"        ⚠️ 类别 {cls} 无增强样本生成")

                if not new_data_all_classes:
                    print("        ❌ 本轮无增强样本生成，提前终止")
                    break

                new_samples = np.vstack(new_data_all_classes)
                temp_over_data = np.vstack((over_data, new_samples))
                temp_over_data = np.unique(temp_over_data, axis=0)

                X_temp, y_temp = temp_over_data[:, :-1], temp_over_data[:, -1].astype(int)
                y_true_temp, y_pred_temp = train_mlp_once_func(X_temp, y_temp, X_t, y_t, num_classes, device_id=0)
                cm_after = confusion_matrix(y_true_temp, y_pred_temp, labels=range(num_classes))
                r1, p1, f1, _, acc1 = measures_of_classify(cm_after)

                print(f"        🧪 增强后 F1: {f1:.4f} | 准确率: {acc1:.4f}")

                if f1 >= best_f1:
                    best_f1, best_acc = f1, acc1
                    over_data = temp_over_data
                    cumulative_new_samples.append(new_samples)  # ✅ 累积每轮的新样本
                else:
                    print("        ⚠️ 增强无显著提升，停止迭代")
                    break

            # ✅ 本折增强完成，合并所有轮次的增强样本
            if cumulative_new_samples:
                all_new_samples = np.vstack(cumulative_new_samples)
                final_new_samples.append(all_new_samples)
                print(f"   📌 本折增强样本累计总数: {all_new_samples.shape[0]}")
            else:
                print("   ⚠️ 本折未保存任何增强样本")

            all_precision.append(p1)
            all_recall.append(r1)
            all_f1.append(best_f1)
            all_acc.append(best_acc)
            print(f"   ✅ 折内最佳 F1: {best_f1:.4f} | 准确率: {best_acc:.4f}")

    print("\n✅ 全部交叉验证完成")
    print(f"📌 平均 F1: {mean(all_f1):.4f}, 平均准确率: {mean(all_acc):.4f}")

    # ✅ 保存增强样本 (使用动态传入的 save_filename)
    if final_new_samples:
        final_new_samples_filtered = [s for s in final_new_samples if s.size > 0]
        if final_new_samples_filtered:
            head_df, total_count = save_final_augmented_data(data, final_new_samples_filtered, filename=save_filename)
            print(f"📦 最终训练样本总数: {total_count}")
            # print(head_df) # 如果不需要可以注释掉避免刷屏

    return mean(all_precision), mean(all_recall), mean(all_f1), float('nan'), mean(all_acc)

def save_final_augmented_data(original_data, final_new_samples, filename): # ✅ 去掉默认硬编码名
    print(f"📦 正在保存最终增强训练集至: {filename} ...")
    print(f"   - 原始样本数: {original_data.shape[0]}")

    all_new_samples = np.vstack(final_new_samples)
    print(f"   - 增强样本数（合并前）: {sum([s.shape[0] for s in final_new_samples])}")

    # 合并原始数据和增强数据
    final_data = np.vstack((original_data, all_new_samples))
    print(f"   - 合并后总样本数: {final_data.shape[0]}")

    # ✅ 使用原始列名（假设原始是 DataFrame 格式）
    if isinstance(original_data, pd.DataFrame):
        col_names = list(original_data.columns)
    else:
        num_features = final_data.shape[1] - 1
        col_names = [f"feature_{i + 1}" for i in range(num_features)] + ["label"]

    df_save = pd.DataFrame(final_data, columns=col_names)
    df_save.to_csv(filename, index=False)
    print(f"✅ 增强训练集已成功保存为: {filename}\n")

    return df_save.head(), final_data.shape[0]


from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, precision_score, recall_score, \
    f1_score, cohen_kappa_score, matthews_corrcoef, balanced_accuracy_score





import pandas as pd
import numpy as np
from collections import defaultdict
from statistics import mean, stdev
from sklearn.metrics import (
    classification_report,
    precision_score,
    recall_score,
    f1_score,
    matthews_corrcoef,
    accuracy_score
)

from sklearn.metrics import precision_score, recall_score
import numpy as np

def compute_gmeans(y_true, y_pred):
    """
    计算 G-means = sqrt(Macro Precision × Macro Recall)
    适用于多分类任务的整体估计
    """
    macro_precision = precision_score(y_true, y_pred, average='macro', zero_division=0)
    macro_recall = recall_score(y_true, y_pred, average='macro', zero_division=0)
    gmeans = np.sqrt(macro_precision * macro_recall)
    return gmeans


def conditional_stratified_sample(df, label_col, frac, min_samples=100, random_state=None):
    """按类分条件采样，若类样本少于 min_samples，则全部保留"""
    sampled = []
    for label, group in df.groupby(label_col):
        if len(group) < min_samples:
            sampled.append(group)
        else:
            sampled.append(group.sample(frac=frac, random_state=random_state))
    return pd.concat(sampled).sample(frac=1.0, random_state=random_state).reset_index(drop=True)


def main(n_runs=5):
    print(f"\n📊 将执行 {n_runs} 次完整跨分类器实验，并自动生成图表和统计报告...\n")

    classifiers = {
        "MLP": (train_mlp_once, True),
        "XGBoost": (train_xgb_once, True),
        "LightGBM": (train_lgbm_once, True),
        "LSTM": (train_lstm_once, False)
    }

    f1_results_for_plot = {}
    sample_tracking_data = [] # 新增：用于记录生成的样本数量

    train = pd.read_csv("multi_train_nsl.csv", index_col=0)
    test = pd.read_csv("multi_test_nsl.csv", index_col=0)
    #train = train.sample(frac=0.01, random_state=42)
    #test = test.sample(frac=0.01, random_state=42)


    feature_cols = train.columns[:-1]
    label_col = train.columns[-1]

    X_train = train[feature_cols].values
    y_train = train[label_col].values.astype(int)
    X_test = test[feature_cols].values
    y_test = test[label_col].values.astype(int)

    num_classes = len(np.unique(np.concatenate([y_train, y_test])))
    train_data_raw = np.hstack((X_train, y_train.reshape(-1, 1)))
    orig_samples_count = train_data_raw.shape[0]

    best_augmented_data_for_lstm = None

    for model_name, (train_func, run_maco) in classifiers.items():
        print(f"\n{'=' * 50}")
        print(f"🚀 开始评估分类器体系: {model_name}")
        print(f"{'=' * 50}")

        base_f1_list = []
        aug_f1_list = []

        for run in range(n_runs):
            # ✅ 设置随机种子，保证5次实验具有统计学意义上的独立性与波动
            # 同时保证全局可复现 (run=0 永远是 seed 42)
            np.random.seed(42 + run)

            print(f"\n--- 🔄 第 {run + 1}/{n_runs} 次运行 ({model_name}) ---")
            current_save_name = f"augmented_{model_name}_run{run}.csv"

            # 1. 对照实验 (Baseline)
            _, y_pred_base = train_func(X_train, y_train, X_test, y_test, num_classes)
            base_f1 = f1_score(y_test, y_pred_base, average='macro', zero_division=0)
            base_f1_list.append(base_f1)

            # 2. 增强实验
            if run_maco:
                print(f"  ▶️ {model_name} 启动 MACO 多轮动态过采样...")
                _ = over_classify_mlp(train_data_raw, train_func, save_filename=current_save_name)

                if os.path.exists(current_save_name):
                    aug_data = pd.read_csv(current_save_name).values
                    best_augmented_data_for_lstm = aug_data
                else:
                    print(f"  ⚠️ 未找到生成的 {current_save_name}，可能增强失败，使用原始数据。")
                    aug_data = train_data_raw
            else:
                borrowed_file = f"augmented_XGBoost_run{run}.csv"
                print(f"  ▶️ {model_name} 仅作为下游测试，尝试加载: {borrowed_file} ...")
                if os.path.exists(borrowed_file):
                    aug_data = pd.read_csv(borrowed_file).values
                else:
                    print("  ⚠️ 警告: 未找到可借用的增强数据，退回使用原始数据。")
                    aug_data = train_data_raw

            X_aug = aug_data[:, :-1]
            y_aug = aug_data[:, -1].astype(int)

            _, y_pred_aug = train_func(X_aug, y_aug, X_test, y_test, num_classes)
            aug_f1 = f1_score(y_test, y_pred_aug, average='macro', zero_division=0)
            aug_f1_list.append(aug_f1)

            # 📈 记录样本生成数量
            aug_samples_count = aug_data.shape[0]
            synthetic_added = aug_samples_count - orig_samples_count
            sample_tracking_data.append({
                "Model": model_name,
                "Run": run + 1,
                "Original Dataset Size": orig_samples_count,
                "Augmented Dataset Size": aug_samples_count,
                "Synthetic Samples Added": synthetic_added
            })

            print(f"  📊 {model_name} 运行 {run + 1} 结果 -> Baseline F1: {base_f1:.4f} | MACO F1: {aug_f1:.4f}")

        f1_results_for_plot[model_name] = (base_f1_list, aug_f1_list)
        print(f"\n✅ {model_name} 实验完成。")
        print(f"  均值 Baseline F1: {mean(base_f1_list):.4f} ± {stdev(base_f1_list):.4f}")
        print(f"  均值 MACO F1    : {mean(aug_f1_list):.4f} ± {stdev(aug_f1_list):.4f}")

    # 执行统计检验并生成所有图表
    perform_stat_test_and_plot(f1_results_for_plot, metric_name="Macro F1")

    # 💾 导出 4：样本生成数量报告 (CSV)
    df_samples = pd.DataFrame(sample_tracking_data)
    # 取每次运行的平均添加数量
    df_samples_summary = df_samples.groupby("Model").mean().round(0).reset_index()
    df_samples_summary.drop(columns=["Run"], inplace=True)
    df_samples_summary.to_csv("Synthetic_Samples_Report.csv", index=False)
    print(f"✅ 样本生成数量报告已保存至: {os.path.abspath('Synthetic_Samples_Report.csv')}")

    print("\n🎉 所有实验圆满结束！请检查生成的图片和 CSV 结果表格。")

if __name__ == "__main__":
    main(n_runs=5)